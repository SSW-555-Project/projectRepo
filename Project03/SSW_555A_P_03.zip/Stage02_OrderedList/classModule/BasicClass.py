class Families:
    def __init__(self, ID):
        self.ID = ID
        self.Married = "NA"
        self.Divorced = "NA"
        self.HusbandID = "NA"
        self.HusbandName = "NA"
        self.WifeID = "NA"
        self.WifeName = "NA"
        self.Children = []


class Individuals: # 
    def __init__(self, ID):
        self.ID = ID
        self.Name = "NA"
        self.Gender = "NA"
        self.Birthday = "NA"
        self.Age = "NA"
        self.Alive = "NA"
        self.Death = "NA"
        self.Child = "None"
        self.Spouse = "NA"

